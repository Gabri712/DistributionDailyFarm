package com.gabriel.mqtt;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;

public class OfficeTemperRoomSubscriber {
	
	
	public static void main(String[] args) {
		String broker = "tcp://localhost:1883";
		String clientID = "Subscriber";
		
		try {
			MqttClient officeClient = new MqttClient(broker, clientID);
			MqttConnectOptions ContOptions = new MqttConnectOptions();
			ContOptions.setCleanSession(true);
			officeClient.setCallback(new OfficeSubscriber());
			
			System.out.println("Connecting to broker ..." + broker);
			officeClient.connect(ContOptions);
			System.out.println("Connected");
			
			officeClient.subscribe("office 5/temper");
			
			System.out.println("printing...");
		
			
		} catch (MqttException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
