package com.gabriel.mqtt;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class OfficeStatusSubscriber {
	
	public static void main(String[] args) {
		String broker = "tcp://localhost:1883";
		String clientID = "Subscriber";
		
		try {
			MqttClient officeClient = new MqttClient(broker, clientID);
			MqttConnectOptions ContOptions = new MqttConnectOptions();
			ContOptions.setCleanSession(true);
			officeClient.setCallback(new OfficeSubscriber());
			
			System.out.println("Connecting to broker ..." + broker);
			officeClient.connect(ContOptions);
			System.out.println("Connected");
			
			officeClient.subscribe("office 5");
			
			System.out.println("printing...");
		
			
		} catch (MqttException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

class OfficeSubscriber implements MqttCallback{

	public void connectionLost(Throwable cause) {
		// TODO Auto-generated method stub
		System.out.println("Connection is lost" + cause.getStackTrace());
	}
	
	
	public void messageArrived(String topic, MqttMessage message) throws Exception {
		// TODO Auto-generated method stub
		
		System.out.println(new String(message.getPayload()) + message.getQos()+" from office number: " + topic);
		
		
	}
	

	public void deliveryComplete(IMqttDeliveryToken token) {
		// TODO Auto-generated method stub
		
		System.out.println("delivery ok..." + token.isComplete());
		
	}
	
}

