package com.gabriel.mqtt;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;

public class OfficeStatusPublisher2 {
	
	
private static MqttClient officeClient;
	
	public static void main(String[] args) {
		String broker = "tcp://localhost:1883";
		String clientID = "Publisher";
		
		try {
			officeClient = new MqttClient(broker, clientID);
			MqttConnectOptions ContOptions = new MqttConnectOptions();
			ContOptions.setCleanSession(true);
			ContOptions.setKeepAliveInterval(180);
			
			
			//Start connection
			
			System.out.println("We are connecting to the broker: " + broker + " ...");
			officeClient.connect(ContOptions);
			System.out.println("Now is connected...");
			
			//Sending messages
			
			
				publishMessages("/office5/temper", "Area Marketing1",17,1, false);
				publishMessages("/office/3","Area Finance 5",7 ,1, false);
				publishMessages("/office5/temper", "Area Finance 22",25,1, false);
				publishMessages("/office5/","Area RH 33",7 ,1, false);
				publishMessages("/office/3","Area Marketing3",7 ,1, false);
				publishMessages("/office5/temper","Area RH 33",23 ,1, false);
				publishMessages("/office5/"," Area IT",19,1, false);
				publishMessages("/office5/"," Area Marketing 33",17,1, false);
				publishMessages("/office/3","Area Finance",7 ,1, false);
				publishMessages("/office5/temper", "Area Finance 22",25,1, false);
				publishMessages("/office5/","Area RH 33",7 ,1, false);
				publishMessages("/office5/temper","Area Marketing4",7 ,1, false);
				publishMessages("/office/3","Area RH 33",23 ,1, false);
				publishMessages("/office5/temper"," Area IT",19,1, false);
				
			
			
			
			//disconecting
			officeClient.disconnect();
			System.out.println("Diconnecting ...");
			officeClient.close();
			System.exit(0);
			
			
		} catch (MqttException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private static void publishMessages(String topic, String payload, int temper,int qos, boolean retained) {
		
		try {
			System.out.println("Publishing message: " + "This Office in " + payload + " the temperature in this office  is " 
					+ temper +"  °C");
			Thread.sleep(1000);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		MqttMessage message = new MqttMessage(payload.getBytes());
		message.setRetained(retained);
		message.setQos(qos);
		
		
		try {
			officeClient.publish(topic, message);
		} catch (MqttPersistenceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MqttException e) {
			// TODO Auto-generated catch block
			
			System.out.println("reason..." + e.getReasonCode());
			System.out.println("message..."+ e.getMessage());
			
			e.printStackTrace();
		}
		
		System.out.println("Messages Published...");
		
	}
	

}
