package grpc.DailyFarm4.WelcomeUser;

import java.io.IOException;
import java.util.logging.Logger;

import grpc.DailyFarm4.WelcomeUser.welcomeUserServiceGrpc.welcomeUserServiceImplBase;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

public class welcomeServer extends welcomeUserServiceImplBase{
	
	
	// First we create a logger to show server side logs in the console. logger instance will be used to log different events at the server console.
		private static final Logger logger = Logger.getLogger(welcomeServer.class.getName());
 
	// Main method would contain the logic to start the server.	For throws keyword refer https://www.javatpoint.com/throw-keyword
	// NOTE: THIS LOGIC WILL BE SAME FOR ALL THE TYPES OF SERVICES
		 public static void main(String[] args) throws IOException, InterruptedException {
			    
			 // The StringServer is the current file name/ class name. Using an instance of this class different methods could be invoked by the client.
			 welcomeServer WelcomeServer = new welcomeServer();

			 	// This is the port number where server will be listening to clients. Refer - https://en.wikipedia.org/wiki/Port_(computer_networking) 
			    int port = 50051;
			    
			    
			    
			    Server server;
				
				try {
					server = ServerBuilder.forPort(port).addService(WelcomeServer).build().start();
					System.out.println("This server is working...");
					server.awaitTermination();
					
				} catch (IOException e){
					e.printStackTrace();
					
				}catch(InterruptedException e) {
					e.printStackTrace();
				}

			    
			    // Here, we create a server on the port defined in in variable "port" and attach a service "stringserver" (instance of the class) defined above.
			    //Server server = ServerBuilder.forPort(port) // Port is defined in line 34
			      //  .addService(WelcomeServer) // Service is defined in line 31
			        //.build() // Build the server
			        //.start(); // Start the server and keep it running for clients to contact.
			    
			    // Giving a logging information on the server console that server has started
			    logger.info("Server started, listening on " + port);
			    		    
			    // Server will be running until externally terminated.
			    //server.awaitTermination();
		 }
		 
		 
		 /*
		
	// These RPC methods have been defined in the proto files. The interface is already present in the ImplBase File.
//		NOTE - YOU MAY NEED TO MODIFY THIS LOGIC FOR YOUR PROJECTS BASED ON TYPE OF THE RPC METHODS 
	// For override Refer - https://docs.oracle.com/javase/8/docs/api/java/lang/Override.html	 
		@Override  
		public void empty(Message request, StreamObserver<Empty> responseObserver) {
			System.out.println("empty message "+ request.getDetail());
				
			//will generate an error CANCELLED: HTTP/2 error code: CANCEL
			Empty reply = Empty.newBuilder().build();
			
			// sending an empty response. No value is there.
			responseObserver.onNext(reply); 
			
		//	StatusRuntimeException er = new StatusRuntimeException(Status.ABORTED);
		//	responseObserver.onError(er);
		  
			responseObserver.onCompleted();
		}


		// This is the second RPC method defined in proto file. It accepts an argument and return one.
		@Override
		public void reverse(StringRequest request, StreamObserver<StringResponse> responseObserver) {
			
			System.out.print("receiving revesre message ");
			
			// Retrieve the value from the request of the client
			StringBuilder stb = new StringBuilder(request.getVal());
			
			// LOGIC of THE METHOD 
			// NOTE: YOU MAY NEED TO MODIFY THIS LOGIC HERE.
			String output = stb.reverse().toString();
			
			// Preparing the reply for the client. Here, response is build and with the value (output) computed by above logic.  
			StringResponse reply = StringResponse.newBuilder().setVal(output).build();
			
			// Sending the reply for each request.
			responseObserver.onNext(reply);
			
			responseObserver.onCompleted();
		}
		
		*/
		
		@Override
		public void welcomeUser(WelcomeUserNam request, StreamObserver<WelcomeUserReply> responseObserver) {
			// TODO Auto-generated method stub
			
			System.out.println("----- Is working receiving user name from client");
			
			WelcomeUserReply reply = WelcomeUserReply.newBuilder().setWelcomeMessageBack("Please type your user name..." + request.getUserName() + "number please " + request.getUserNum()).build();
			
			
            responseObserver.onNext(reply);
			responseObserver.onCompleted();
			
			super.welcomeUser(request, responseObserver);
		}
		
		

		@Override
		public void dailyIsland(Island request, StreamObserver<IslandReply> responseObserver) {
			// TODO Auto-generated method stub
			
			
           System.out.println("----- Is working receiving number of Island from client");
			
			IslandReply reply = IslandReply.newBuilder().setGoalIsland("Please type your Island number ..." + request.getNoIsland()).build();
			
            responseObserver.onNext(reply);
			responseObserver.onCompleted();
			
			
			super.dailyIsland(request, responseObserver);
		}

		@Override
		public void dailyWelcome(welcomeMessageT request, StreamObserver<welcomeMessageTReply> responseObserver) {
			// TODO Auto-generated method stub
			
            System.out.println("----- Is working receiving number of Island from client");
			
			welcomeMessageTReply reply = welcomeMessageTReply.newBuilder().setTotMessage("Please type your Island number ..." + request.getWelcomeMessage()).build();
			
            responseObserver.onNext(reply);
			responseObserver.onCompleted();
			
			super.dailyWelcome(request, responseObserver);
		}



}
