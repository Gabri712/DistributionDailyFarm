package grpc.DailyFarm4.WelcomeUser;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 * Service Definition
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: welcomeUser.proto")
public final class welcomeUserServiceGrpc {

  private welcomeUserServiceGrpc() {}

  public static final String SERVICE_NAME = "dailyFarm4.welcomeUserService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarm4.WelcomeUser.WelcomeUserNam,
      grpc.DailyFarm4.WelcomeUser.WelcomeUserReply> getWelcomeUserMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "WelcomeUser",
      requestType = grpc.DailyFarm4.WelcomeUser.WelcomeUserNam.class,
      responseType = grpc.DailyFarm4.WelcomeUser.WelcomeUserReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.DailyFarm4.WelcomeUser.WelcomeUserNam,
      grpc.DailyFarm4.WelcomeUser.WelcomeUserReply> getWelcomeUserMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarm4.WelcomeUser.WelcomeUserNam, grpc.DailyFarm4.WelcomeUser.WelcomeUserReply> getWelcomeUserMethod;
    if ((getWelcomeUserMethod = welcomeUserServiceGrpc.getWelcomeUserMethod) == null) {
      synchronized (welcomeUserServiceGrpc.class) {
        if ((getWelcomeUserMethod = welcomeUserServiceGrpc.getWelcomeUserMethod) == null) {
          welcomeUserServiceGrpc.getWelcomeUserMethod = getWelcomeUserMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarm4.WelcomeUser.WelcomeUserNam, grpc.DailyFarm4.WelcomeUser.WelcomeUserReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "dailyFarm4.welcomeUserService", "WelcomeUser"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarm4.WelcomeUser.WelcomeUserNam.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarm4.WelcomeUser.WelcomeUserReply.getDefaultInstance()))
                  .setSchemaDescriptor(new welcomeUserServiceMethodDescriptorSupplier("WelcomeUser"))
                  .build();
          }
        }
     }
     return getWelcomeUserMethod;
  }

  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarm4.WelcomeUser.Island,
      grpc.DailyFarm4.WelcomeUser.IslandReply> getDailyIslandMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DailyIsland",
      requestType = grpc.DailyFarm4.WelcomeUser.Island.class,
      responseType = grpc.DailyFarm4.WelcomeUser.IslandReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.DailyFarm4.WelcomeUser.Island,
      grpc.DailyFarm4.WelcomeUser.IslandReply> getDailyIslandMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarm4.WelcomeUser.Island, grpc.DailyFarm4.WelcomeUser.IslandReply> getDailyIslandMethod;
    if ((getDailyIslandMethod = welcomeUserServiceGrpc.getDailyIslandMethod) == null) {
      synchronized (welcomeUserServiceGrpc.class) {
        if ((getDailyIslandMethod = welcomeUserServiceGrpc.getDailyIslandMethod) == null) {
          welcomeUserServiceGrpc.getDailyIslandMethod = getDailyIslandMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarm4.WelcomeUser.Island, grpc.DailyFarm4.WelcomeUser.IslandReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "dailyFarm4.welcomeUserService", "DailyIsland"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarm4.WelcomeUser.Island.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarm4.WelcomeUser.IslandReply.getDefaultInstance()))
                  .setSchemaDescriptor(new welcomeUserServiceMethodDescriptorSupplier("DailyIsland"))
                  .build();
          }
        }
     }
     return getDailyIslandMethod;
  }

  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarm4.WelcomeUser.welcomeMessageT,
      grpc.DailyFarm4.WelcomeUser.welcomeMessageTReply> getDailyWelcomeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "dailyWelcome",
      requestType = grpc.DailyFarm4.WelcomeUser.welcomeMessageT.class,
      responseType = grpc.DailyFarm4.WelcomeUser.welcomeMessageTReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.DailyFarm4.WelcomeUser.welcomeMessageT,
      grpc.DailyFarm4.WelcomeUser.welcomeMessageTReply> getDailyWelcomeMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarm4.WelcomeUser.welcomeMessageT, grpc.DailyFarm4.WelcomeUser.welcomeMessageTReply> getDailyWelcomeMethod;
    if ((getDailyWelcomeMethod = welcomeUserServiceGrpc.getDailyWelcomeMethod) == null) {
      synchronized (welcomeUserServiceGrpc.class) {
        if ((getDailyWelcomeMethod = welcomeUserServiceGrpc.getDailyWelcomeMethod) == null) {
          welcomeUserServiceGrpc.getDailyWelcomeMethod = getDailyWelcomeMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarm4.WelcomeUser.welcomeMessageT, grpc.DailyFarm4.WelcomeUser.welcomeMessageTReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "dailyFarm4.welcomeUserService", "dailyWelcome"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarm4.WelcomeUser.welcomeMessageT.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarm4.WelcomeUser.welcomeMessageTReply.getDefaultInstance()))
                  .setSchemaDescriptor(new welcomeUserServiceMethodDescriptorSupplier("dailyWelcome"))
                  .build();
          }
        }
     }
     return getDailyWelcomeMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static welcomeUserServiceStub newStub(io.grpc.Channel channel) {
    return new welcomeUserServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static welcomeUserServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new welcomeUserServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static welcomeUserServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new welcomeUserServiceFutureStub(channel);
  }

  /**
   * <pre>
   * Service Definition
   * </pre>
   */
  public static abstract class welcomeUserServiceImplBase implements io.grpc.BindableService {

    /**
     */
    public void welcomeUser(grpc.DailyFarm4.WelcomeUser.WelcomeUserNam request,
        io.grpc.stub.StreamObserver<grpc.DailyFarm4.WelcomeUser.WelcomeUserReply> responseObserver) {
      asyncUnimplementedUnaryCall(getWelcomeUserMethod(), responseObserver);
    }

    /**
     */
    public void dailyIsland(grpc.DailyFarm4.WelcomeUser.Island request,
        io.grpc.stub.StreamObserver<grpc.DailyFarm4.WelcomeUser.IslandReply> responseObserver) {
      asyncUnimplementedUnaryCall(getDailyIslandMethod(), responseObserver);
    }

    /**
     */
    public void dailyWelcome(grpc.DailyFarm4.WelcomeUser.welcomeMessageT request,
        io.grpc.stub.StreamObserver<grpc.DailyFarm4.WelcomeUser.welcomeMessageTReply> responseObserver) {
      asyncUnimplementedUnaryCall(getDailyWelcomeMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getWelcomeUserMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.DailyFarm4.WelcomeUser.WelcomeUserNam,
                grpc.DailyFarm4.WelcomeUser.WelcomeUserReply>(
                  this, METHODID_WELCOME_USER)))
          .addMethod(
            getDailyIslandMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.DailyFarm4.WelcomeUser.Island,
                grpc.DailyFarm4.WelcomeUser.IslandReply>(
                  this, METHODID_DAILY_ISLAND)))
          .addMethod(
            getDailyWelcomeMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.DailyFarm4.WelcomeUser.welcomeMessageT,
                grpc.DailyFarm4.WelcomeUser.welcomeMessageTReply>(
                  this, METHODID_DAILY_WELCOME)))
          .build();
    }
  }

  /**
   * <pre>
   * Service Definition
   * </pre>
   */
  public static final class welcomeUserServiceStub extends io.grpc.stub.AbstractStub<welcomeUserServiceStub> {
    private welcomeUserServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private welcomeUserServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected welcomeUserServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new welcomeUserServiceStub(channel, callOptions);
    }

    /**
     */
    public void welcomeUser(grpc.DailyFarm4.WelcomeUser.WelcomeUserNam request,
        io.grpc.stub.StreamObserver<grpc.DailyFarm4.WelcomeUser.WelcomeUserReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getWelcomeUserMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void dailyIsland(grpc.DailyFarm4.WelcomeUser.Island request,
        io.grpc.stub.StreamObserver<grpc.DailyFarm4.WelcomeUser.IslandReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getDailyIslandMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void dailyWelcome(grpc.DailyFarm4.WelcomeUser.welcomeMessageT request,
        io.grpc.stub.StreamObserver<grpc.DailyFarm4.WelcomeUser.welcomeMessageTReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getDailyWelcomeMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * Service Definition
   * </pre>
   */
  public static final class welcomeUserServiceBlockingStub extends io.grpc.stub.AbstractStub<welcomeUserServiceBlockingStub> {
    private welcomeUserServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private welcomeUserServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected welcomeUserServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new welcomeUserServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public grpc.DailyFarm4.WelcomeUser.WelcomeUserReply welcomeUser(grpc.DailyFarm4.WelcomeUser.WelcomeUserNam request) {
      return blockingUnaryCall(
          getChannel(), getWelcomeUserMethod(), getCallOptions(), request);
    }

    /**
     */
    public grpc.DailyFarm4.WelcomeUser.IslandReply dailyIsland(grpc.DailyFarm4.WelcomeUser.Island request) {
      return blockingUnaryCall(
          getChannel(), getDailyIslandMethod(), getCallOptions(), request);
    }

    /**
     */
    public grpc.DailyFarm4.WelcomeUser.welcomeMessageTReply dailyWelcome(grpc.DailyFarm4.WelcomeUser.welcomeMessageT request) {
      return blockingUnaryCall(
          getChannel(), getDailyWelcomeMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * Service Definition
   * </pre>
   */
  public static final class welcomeUserServiceFutureStub extends io.grpc.stub.AbstractStub<welcomeUserServiceFutureStub> {
    private welcomeUserServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private welcomeUserServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected welcomeUserServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new welcomeUserServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.DailyFarm4.WelcomeUser.WelcomeUserReply> welcomeUser(
        grpc.DailyFarm4.WelcomeUser.WelcomeUserNam request) {
      return futureUnaryCall(
          getChannel().newCall(getWelcomeUserMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.DailyFarm4.WelcomeUser.IslandReply> dailyIsland(
        grpc.DailyFarm4.WelcomeUser.Island request) {
      return futureUnaryCall(
          getChannel().newCall(getDailyIslandMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.DailyFarm4.WelcomeUser.welcomeMessageTReply> dailyWelcome(
        grpc.DailyFarm4.WelcomeUser.welcomeMessageT request) {
      return futureUnaryCall(
          getChannel().newCall(getDailyWelcomeMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_WELCOME_USER = 0;
  private static final int METHODID_DAILY_ISLAND = 1;
  private static final int METHODID_DAILY_WELCOME = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final welcomeUserServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(welcomeUserServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_WELCOME_USER:
          serviceImpl.welcomeUser((grpc.DailyFarm4.WelcomeUser.WelcomeUserNam) request,
              (io.grpc.stub.StreamObserver<grpc.DailyFarm4.WelcomeUser.WelcomeUserReply>) responseObserver);
          break;
        case METHODID_DAILY_ISLAND:
          serviceImpl.dailyIsland((grpc.DailyFarm4.WelcomeUser.Island) request,
              (io.grpc.stub.StreamObserver<grpc.DailyFarm4.WelcomeUser.IslandReply>) responseObserver);
          break;
        case METHODID_DAILY_WELCOME:
          serviceImpl.dailyWelcome((grpc.DailyFarm4.WelcomeUser.welcomeMessageT) request,
              (io.grpc.stub.StreamObserver<grpc.DailyFarm4.WelcomeUser.welcomeMessageTReply>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class welcomeUserServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    welcomeUserServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return grpc.DailyFarm4.WelcomeUser.DailyFarmImplementation.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("welcomeUserService");
    }
  }

  private static final class welcomeUserServiceFileDescriptorSupplier
      extends welcomeUserServiceBaseDescriptorSupplier {
    welcomeUserServiceFileDescriptorSupplier() {}
  }

  private static final class welcomeUserServiceMethodDescriptorSupplier
      extends welcomeUserServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    welcomeUserServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (welcomeUserServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new welcomeUserServiceFileDescriptorSupplier())
              .addMethod(getWelcomeUserMethod())
              .addMethod(getDailyIslandMethod())
              .addMethod(getDailyWelcomeMethod())
              .build();
        }
      }
    }
    return result;
  }
}
