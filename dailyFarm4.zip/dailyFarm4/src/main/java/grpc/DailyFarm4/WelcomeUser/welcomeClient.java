package grpc.DailyFarm4.WelcomeUser;

import java.util.logging.Logger;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;

public class welcomeClient {

	// First we create a logger to show client side logs in the console. logger instance will be used to log different events at the client console.
		// This is optional. Could be used if needed.
		private static  Logger logger = Logger.getLogger(welcomeClient.class.getName());

		// Creating stubs for establishing the connection with server.
		// Blocking stub
		private static welcomeUserServiceGrpc.welcomeUserServiceBlockingStub blockingStub;
		// Asynch stub
		private static welcomeUserServiceGrpc.welcomeUserServiceStub asyncStub;
		
		// The main method will have the logic for client.
		public static void main(String[] args) throws Exception {
		// First a channel is being created to the server from client. Here, we provide the server name (localhost) and port (50055).
			// As it is a local demo of GRPC, we can have non-secured channel (usePlaintext).
			ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50051).usePlaintext().build();

			//stubs -- generate from proto
			blockingStub = welcomeUserServiceGrpc.newBlockingStub(channel);
			asyncStub = welcomeUserServiceGrpc.newStub(channel);

			// Unary RPC call
			WelcomeUser();
			DailyIsland();
			dailyWelcome();

			//  empty(); 	//passing an empty message - no server reply, error message

			// Closing the channel once message has been passed.		
			channel.shutdown();

		}

     /*
		//unary rpc
		public static void reverse() {
			// First creating a request message. Here, the message contains a string in setVal
			StringRequest req = StringRequest.newBuilder().setVal("Hello").build();
			//  Calling a remote RPC method using blocking stub defined in main method. req is the message we want to pass.
			StringResponse response = blockingStub.reverse(req);

			//response contains the output from the server side. Here, we are printing the value contained by response. 
			System.out.println(response.getVal());
		}


		//unary rpc
		public static void empty() {
			// First creating a request message. Here, the message contains emply message as defined in proto enum
			Message req = Message.newBuilder().setDetail(Enum.UNKNOWN).build();
			try {
				// Calling a remote RPC method using blocking stub defined in main method. req is the message we want to pass.
				Empty response = blockingStub.empty(req);
				//response contains the output from the server side. Here, we are printing the value contained by response.
				System.out.println("one response " + response.toString());

			}catch(StatusRuntimeException ex) {
				// Print if any error/exception is generated.
				System.out.println( ex.getMessage());
				//ex.printStackTrace();
			}


		}
		
		*/
		
		public static void WelcomeUser() {
			
			// First creating a request message. Here, the message contains a string in setVal
			WelcomeUserNam req = WelcomeUserNam.newBuilder().setUserName("Hello, type your user name...").build();
			
			WelcomeUserNam req1 = WelcomeUserNam.newBuilder().setUserNum("Hello, type your user number...").build();
			//  Calling a remote RPC method using blocking stub defined in main method. req is the message we want to pass.
			
			WelcomeUserReply response = blockingStub.welcomeUser(req);
			WelcomeUserReply response1 = blockingStub.welcomeUser(req1);

			//response contains the output from the server side. Here, we are printing the value contained by response. 
			System.out.println(response.getWelcomeMessageBack());
			System.out.println(response1.getWelcomeMessageBack());
			
		}
		
		
		
        public static void DailyIsland() {
			
			// First creating a request message. Here, the message contains a string in setVal
			Island req = Island.newBuilder().setNoIsland("Hello, type number of island...").build();
			
			Island req1 = Island.newBuilder().setCowNum("Hello, type the number of cow...").build();
			//  Calling a remote RPC method using blocking stub defined in main method. req is the message we want to pass.
			
			IslandReply response = blockingStub.dailyIsland(req);
			IslandReply response1 = blockingStub.dailyIsland(req1);

			//response contains the output from the server side. Here, we are printing the value contained by response. 
			System.out.println(response.getGoalIsland());
			System.out.println(response1.getGoalIsland());
			
		}
        
        
      
        
        public static void dailyWelcome() {
			
			// First creating a request message. Here, the message contains a string in setVal
        	welcomeMessageT req = welcomeMessageT.newBuilder().setWelcomeMessage("Hello, would you like a special message? ...").build();
			
			//  Calling a remote RPC method using blocking stub defined in main method. req is the message we want to pass.
			
			welcomeMessageTReply response = blockingStub.dailyWelcome(req);

			//response contains the output from the server side. Here, we are printing the value contained by response. 
			System.out.println(response.getTotMessage());
			
			
		}
		
		
		
	
}
