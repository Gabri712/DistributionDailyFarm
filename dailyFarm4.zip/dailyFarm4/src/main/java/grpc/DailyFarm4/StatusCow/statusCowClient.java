package grpc.DailyFarm4.StatusCow;

import java.util.Iterator;
import java.util.logging.Logger;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;



public class statusCowClient {
	
	
	// First we create a logger to show client side logs in the console. logger instance will be used to log different events at the client console.
				// This is optional. Could be used if needed.
				private static  Logger logger = Logger.getLogger(statusCowClient.class.getName());

				// Creating stubs for establishing the connection with server.
				// Blocking stub
				private static ProfitMilkGrpc.ProfitMilkBlockingStub blockingStub;
				// Async stub
				private static ProfitMilkGrpc.ProfitMilkStub asyncStub;
				
				// The main method will have the logic for client.
				public static void main(String[] args) throws Exception {
				// First a channel is being created to the server from client. Here, we provide the server name (localhost) and port (50055).
					// As it is a local demo of GRPC, we can have non-secured channel (usePlaintext).
					ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50051).usePlaintext().build();

					//stubs -- generate from proto
			        
			        blockingStub = ProfitMilkGrpc.newBlockingStub(channel);
					asyncStub = ProfitMilkGrpc.newStub(channel);
			
					// Unary RPC call
					splitAsync();
					splitBlocking();
				
					//  empty(); 	//passing an empty message - no server reply, error message

					// Closing the channel once message has been passed.		
					channel.shutdown();

				}
				
				
				
				public static void splitAsync() {
					
					// First crea ting a request message. Here, the message contains a string in setVal
					ProfitCow request = ProfitCow.newBuilder().setNameCow("susie").build();

					// Handling the stream from server using onNext (logic for handling each message in stream), onError, onCompleted (logic will be executed after the completion of stream)
					StreamObserver<ProfitCowReply> responseObserver = new StreamObserver<ProfitCowReply>() {

					
						 @Override
						public void onNext(ProfitCowReply reply) {
					        // Handle each server streaming response
							System.out.println("working");
					        System.out.println("Cow: " + reply.getNameCow1());
					        System.out.println("Money from cheese production: " + reply.getMoneyCheeseR());
					        System.out.println("Average milk production: " + reply.getAveragecow());
					      }

						@Override
						public void onError(Throwable t) {
							t.printStackTrace();

						}

						@Override
						public void onCompleted() {
							System.out.println("stream is completed ... receive ");
						}


					};

					// Here, we are calling the Remote split method. On receiving the message from server the onNext, onError, onCompleted will be called (as defined above). 
					asyncStub.split(request, responseObserver);


					try {
						Thread.sleep(30000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}


				}

				//blocking server-streaming
				public static void splitBlocking() {
					// First creating a request message. Here, the message contains a string in setVal
					ProfitCow request = ProfitCow.newBuilder().setNameCow(" message susie").build();

					// as this call is blocking. The client will not proceed until all the messages in stream has been received. 
					try {
						// Iterating each message in response when calling remote split RPC method.
						Iterator<ProfitCowReply> responce = blockingStub.split(request);
						
						// Client keeps a check on the next message in stream.
						while(responce.hasNext()) {
							ProfitCowReply temp = responce.next();
							System.out.println(temp.getAveragecow());				
						}

					} catch (StatusRuntimeException e) {
						e.printStackTrace();
					}
					
				}
				


}
	
	
	
	

	

	
	  