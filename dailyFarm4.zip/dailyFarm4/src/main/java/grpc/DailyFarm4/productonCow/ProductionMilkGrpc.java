package grpc.DailyFarm4.productonCow;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: productonCow.proto")
public final class ProductionMilkGrpc {

  private ProductionMilkGrpc() {}

  public static final String SERVICE_NAME = "dailyFarm4.ProductionMilk";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarm4.productonCow.LtsMilk,
      grpc.DailyFarm4.productonCow.LtsMilkReply> getTotMilkMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "TotMilk",
      requestType = grpc.DailyFarm4.productonCow.LtsMilk.class,
      responseType = grpc.DailyFarm4.productonCow.LtsMilkReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.DailyFarm4.productonCow.LtsMilk,
      grpc.DailyFarm4.productonCow.LtsMilkReply> getTotMilkMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarm4.productonCow.LtsMilk, grpc.DailyFarm4.productonCow.LtsMilkReply> getTotMilkMethod;
    if ((getTotMilkMethod = ProductionMilkGrpc.getTotMilkMethod) == null) {
      synchronized (ProductionMilkGrpc.class) {
        if ((getTotMilkMethod = ProductionMilkGrpc.getTotMilkMethod) == null) {
          ProductionMilkGrpc.getTotMilkMethod = getTotMilkMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarm4.productonCow.LtsMilk, grpc.DailyFarm4.productonCow.LtsMilkReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "dailyFarm4.ProductionMilk", "TotMilk"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarm4.productonCow.LtsMilk.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarm4.productonCow.LtsMilkReply.getDefaultInstance()))
                  .setSchemaDescriptor(new ProductionMilkMethodDescriptorSupplier("TotMilk"))
                  .build();
          }
        }
     }
     return getTotMilkMethod;
  }

  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarm4.productonCow.MilkCow,
      grpc.DailyFarm4.productonCow.MilkCowReply> getProductionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "production",
      requestType = grpc.DailyFarm4.productonCow.MilkCow.class,
      responseType = grpc.DailyFarm4.productonCow.MilkCowReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.CLIENT_STREAMING)
  public static io.grpc.MethodDescriptor<grpc.DailyFarm4.productonCow.MilkCow,
      grpc.DailyFarm4.productonCow.MilkCowReply> getProductionMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarm4.productonCow.MilkCow, grpc.DailyFarm4.productonCow.MilkCowReply> getProductionMethod;
    if ((getProductionMethod = ProductionMilkGrpc.getProductionMethod) == null) {
      synchronized (ProductionMilkGrpc.class) {
        if ((getProductionMethod = ProductionMilkGrpc.getProductionMethod) == null) {
          ProductionMilkGrpc.getProductionMethod = getProductionMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarm4.productonCow.MilkCow, grpc.DailyFarm4.productonCow.MilkCowReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.CLIENT_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "dailyFarm4.ProductionMilk", "production"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarm4.productonCow.MilkCow.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarm4.productonCow.MilkCowReply.getDefaultInstance()))
                  .setSchemaDescriptor(new ProductionMilkMethodDescriptorSupplier("production"))
                  .build();
          }
        }
     }
     return getProductionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarm4.productonCow.ProfitCheese,
      grpc.DailyFarm4.productonCow.ProfitCheeseReply> getProfCheeseMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ProfCheese",
      requestType = grpc.DailyFarm4.productonCow.ProfitCheese.class,
      responseType = grpc.DailyFarm4.productonCow.ProfitCheeseReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.DailyFarm4.productonCow.ProfitCheese,
      grpc.DailyFarm4.productonCow.ProfitCheeseReply> getProfCheeseMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarm4.productonCow.ProfitCheese, grpc.DailyFarm4.productonCow.ProfitCheeseReply> getProfCheeseMethod;
    if ((getProfCheeseMethod = ProductionMilkGrpc.getProfCheeseMethod) == null) {
      synchronized (ProductionMilkGrpc.class) {
        if ((getProfCheeseMethod = ProductionMilkGrpc.getProfCheeseMethod) == null) {
          ProductionMilkGrpc.getProfCheeseMethod = getProfCheeseMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarm4.productonCow.ProfitCheese, grpc.DailyFarm4.productonCow.ProfitCheeseReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "dailyFarm4.ProductionMilk", "ProfCheese"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarm4.productonCow.ProfitCheese.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarm4.productonCow.ProfitCheeseReply.getDefaultInstance()))
                  .setSchemaDescriptor(new ProductionMilkMethodDescriptorSupplier("ProfCheese"))
                  .build();
          }
        }
     }
     return getProfCheeseMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ProductionMilkStub newStub(io.grpc.Channel channel) {
    return new ProductionMilkStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ProductionMilkBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new ProductionMilkBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ProductionMilkFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new ProductionMilkFutureStub(channel);
  }

  /**
   */
  public static abstract class ProductionMilkImplBase implements io.grpc.BindableService {

    /**
     */
    public void totMilk(grpc.DailyFarm4.productonCow.LtsMilk request,
        io.grpc.stub.StreamObserver<grpc.DailyFarm4.productonCow.LtsMilkReply> responseObserver) {
      asyncUnimplementedUnaryCall(getTotMilkMethod(), responseObserver);
    }

    /**
     */
    public io.grpc.stub.StreamObserver<grpc.DailyFarm4.productonCow.MilkCow> production(
        io.grpc.stub.StreamObserver<grpc.DailyFarm4.productonCow.MilkCowReply> responseObserver) {
      return asyncUnimplementedStreamingCall(getProductionMethod(), responseObserver);
    }

    /**
     */
    public void profCheese(grpc.DailyFarm4.productonCow.ProfitCheese request,
        io.grpc.stub.StreamObserver<grpc.DailyFarm4.productonCow.ProfitCheeseReply> responseObserver) {
      asyncUnimplementedUnaryCall(getProfCheeseMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getTotMilkMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.DailyFarm4.productonCow.LtsMilk,
                grpc.DailyFarm4.productonCow.LtsMilkReply>(
                  this, METHODID_TOT_MILK)))
          .addMethod(
            getProductionMethod(),
            asyncClientStreamingCall(
              new MethodHandlers<
                grpc.DailyFarm4.productonCow.MilkCow,
                grpc.DailyFarm4.productonCow.MilkCowReply>(
                  this, METHODID_PRODUCTION)))
          .addMethod(
            getProfCheeseMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.DailyFarm4.productonCow.ProfitCheese,
                grpc.DailyFarm4.productonCow.ProfitCheeseReply>(
                  this, METHODID_PROF_CHEESE)))
          .build();
    }
  }

  /**
   */
  public static final class ProductionMilkStub extends io.grpc.stub.AbstractStub<ProductionMilkStub> {
    private ProductionMilkStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ProductionMilkStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ProductionMilkStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ProductionMilkStub(channel, callOptions);
    }

    /**
     */
    public void totMilk(grpc.DailyFarm4.productonCow.LtsMilk request,
        io.grpc.stub.StreamObserver<grpc.DailyFarm4.productonCow.LtsMilkReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getTotMilkMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public io.grpc.stub.StreamObserver<grpc.DailyFarm4.productonCow.MilkCow> production(
        io.grpc.stub.StreamObserver<grpc.DailyFarm4.productonCow.MilkCowReply> responseObserver) {
      return asyncClientStreamingCall(
          getChannel().newCall(getProductionMethod(), getCallOptions()), responseObserver);
    }

    /**
     */
    public void profCheese(grpc.DailyFarm4.productonCow.ProfitCheese request,
        io.grpc.stub.StreamObserver<grpc.DailyFarm4.productonCow.ProfitCheeseReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getProfCheeseMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class ProductionMilkBlockingStub extends io.grpc.stub.AbstractStub<ProductionMilkBlockingStub> {
    private ProductionMilkBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ProductionMilkBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ProductionMilkBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ProductionMilkBlockingStub(channel, callOptions);
    }

    /**
     */
    public grpc.DailyFarm4.productonCow.LtsMilkReply totMilk(grpc.DailyFarm4.productonCow.LtsMilk request) {
      return blockingUnaryCall(
          getChannel(), getTotMilkMethod(), getCallOptions(), request);
    }

    /**
     */
    public grpc.DailyFarm4.productonCow.ProfitCheeseReply profCheese(grpc.DailyFarm4.productonCow.ProfitCheese request) {
      return blockingUnaryCall(
          getChannel(), getProfCheeseMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class ProductionMilkFutureStub extends io.grpc.stub.AbstractStub<ProductionMilkFutureStub> {
    private ProductionMilkFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ProductionMilkFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ProductionMilkFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ProductionMilkFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.DailyFarm4.productonCow.LtsMilkReply> totMilk(
        grpc.DailyFarm4.productonCow.LtsMilk request) {
      return futureUnaryCall(
          getChannel().newCall(getTotMilkMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.DailyFarm4.productonCow.ProfitCheeseReply> profCheese(
        grpc.DailyFarm4.productonCow.ProfitCheese request) {
      return futureUnaryCall(
          getChannel().newCall(getProfCheeseMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_TOT_MILK = 0;
  private static final int METHODID_PROF_CHEESE = 1;
  private static final int METHODID_PRODUCTION = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final ProductionMilkImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(ProductionMilkImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_TOT_MILK:
          serviceImpl.totMilk((grpc.DailyFarm4.productonCow.LtsMilk) request,
              (io.grpc.stub.StreamObserver<grpc.DailyFarm4.productonCow.LtsMilkReply>) responseObserver);
          break;
        case METHODID_PROF_CHEESE:
          serviceImpl.profCheese((grpc.DailyFarm4.productonCow.ProfitCheese) request,
              (io.grpc.stub.StreamObserver<grpc.DailyFarm4.productonCow.ProfitCheeseReply>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_PRODUCTION:
          return (io.grpc.stub.StreamObserver<Req>) serviceImpl.production(
              (io.grpc.stub.StreamObserver<grpc.DailyFarm4.productonCow.MilkCowReply>) responseObserver);
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class ProductionMilkBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ProductionMilkBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return grpc.DailyFarm4.productonCow.DailyFarmImplementation.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("ProductionMilk");
    }
  }

  private static final class ProductionMilkFileDescriptorSupplier
      extends ProductionMilkBaseDescriptorSupplier {
    ProductionMilkFileDescriptorSupplier() {}
  }

  private static final class ProductionMilkMethodDescriptorSupplier
      extends ProductionMilkBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    ProductionMilkMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ProductionMilkGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ProductionMilkFileDescriptorSupplier())
              .addMethod(getTotMilkMethod())
              .addMethod(getProductionMethod())
              .addMethod(getProfCheeseMethod())
              .build();
        }
      }
    }
    return result;
  }
}
