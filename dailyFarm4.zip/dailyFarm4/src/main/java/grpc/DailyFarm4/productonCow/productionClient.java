package grpc.DailyFarm4.productonCow;

import java.util.Random;
import java.util.logging.Logger;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

public class productionClient {
	
	
	// First we create a logger to show client side logs in the console. logger instance will be used to log different events at the client console.
		// This is optional. Could be used if needed.
		private static  Logger logger = Logger.getLogger(productionClient.class.getName());

		// Creating stubs for establishing the connection with server.
				// Blocking stub
		private static ProductionMilkGrpc.ProductionMilkBlockingStub blockingStub;
		// Asynch stub
		private static ProductionMilkGrpc.ProductionMilkStub asyncStub;
		
		// The main method will have the logic for client.
		public static void main(String[] args) throws Exception {
			// First a channel is being created to the server from client. Here, we provide the server name (localhost) and port (50057).
					// As it is a local demo of GRPC, we can have non-secured channel (usePlaintext).
			ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50051).usePlaintext().build();

			//stubs -- generate from proto
			blockingStub = ProductionMilkGrpc.newBlockingStub(channel);
			asyncStub = ProductionMilkGrpc.newStub(channel);

			// clientstreaming method call
			production1();
			
			// Closing the channel once message has been passed.
			channel.shutdown();

		}

		private static void production1() {
			// TODO Auto-generated method stub
			
			
			// Handling the stream for client using onNext (logic for handling each message in stream), onError, onCompleted (logic will be executed after the completion of stream)
			StreamObserver<MilkCowReply> responseObserver = new StreamObserver<MilkCowReply>() {

				@Override
				public void onNext(MilkCowReply milkCowReply) {
					
					System.out.println("Collecting this amount of milk you can get: ");
					System.out.println("Delicius: " + milkCowReply.getNumberCheeseR() +" cheeses from your Farm...");
					
				}
 
				@Override
				public void onError(Throwable t) {
					// TODO Auto-generated method stub

				}

				@Override
				public void onCompleted() {
					System.out.println(" message reply completed ");

				}

			};

			// Here, we are calling the Remote length method. Using onNext, client sends a stream of messages.
			StreamObserver<MilkCow> requestObserver = asyncStub.production(responseObserver);

			try {
				
				// create and send first message
				MilkCow milkCow1 = MilkCow.newBuilder().setNameCow("Lola").setMilkLts(17.5f).setNoIslandCow("1").build();
				requestObserver.onNext(milkCow1);
				
				// create and send 2nd message
				MilkCow milkCow2 = MilkCow.newBuilder().setNameCow("Louis").setMilkLts(9.3f).setNoIslandCow("2").build();
				requestObserver.onNext(milkCow2);
				
				// create and send third message
				MilkCow milkCow3 = MilkCow.newBuilder().setNameCow("Susie").setMilkLts(20.7f).setNoIslandCow("3").build();
				requestObserver.onNext(milkCow3);

				// Mark the end of requests
				requestObserver.onCompleted();


				// Sleep for a bit before sending the next one.
				Thread.sleep(new Random().nextInt(1000) + 500);


			} catch (RuntimeException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {			
				e.printStackTrace();
			}
			
			
		}
		

}



