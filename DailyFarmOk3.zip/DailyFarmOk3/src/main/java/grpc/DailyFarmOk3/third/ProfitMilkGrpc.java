package grpc.DailyFarmOk3.third;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: production.proto")
public final class ProfitMilkGrpc {

  private ProfitMilkGrpc() {}

  public static final String SERVICE_NAME = "DailyFarmOk3.ProfitMilk";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarmOk3.third.LtsMilk,
      grpc.DailyFarmOk3.third.LtsMilkReply> getTotMilkMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "TotMilk",
      requestType = grpc.DailyFarmOk3.third.LtsMilk.class,
      responseType = grpc.DailyFarmOk3.third.LtsMilkReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.DailyFarmOk3.third.LtsMilk,
      grpc.DailyFarmOk3.third.LtsMilkReply> getTotMilkMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarmOk3.third.LtsMilk, grpc.DailyFarmOk3.third.LtsMilkReply> getTotMilkMethod;
    if ((getTotMilkMethod = ProfitMilkGrpc.getTotMilkMethod) == null) {
      synchronized (ProfitMilkGrpc.class) {
        if ((getTotMilkMethod = ProfitMilkGrpc.getTotMilkMethod) == null) {
          ProfitMilkGrpc.getTotMilkMethod = getTotMilkMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarmOk3.third.LtsMilk, grpc.DailyFarmOk3.third.LtsMilkReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DailyFarmOk3.ProfitMilk", "TotMilk"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.third.LtsMilk.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.third.LtsMilkReply.getDefaultInstance()))
                  .setSchemaDescriptor(new ProfitMilkMethodDescriptorSupplier("TotMilk"))
                  .build();
          }
        }
     }
     return getTotMilkMethod;
  }

  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarmOk3.third.NoCheese,
      grpc.DailyFarmOk3.third.NoCheeseReply> getCheeseWMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CheeseW",
      requestType = grpc.DailyFarmOk3.third.NoCheese.class,
      responseType = grpc.DailyFarmOk3.third.NoCheeseReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.DailyFarmOk3.third.NoCheese,
      grpc.DailyFarmOk3.third.NoCheeseReply> getCheeseWMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarmOk3.third.NoCheese, grpc.DailyFarmOk3.third.NoCheeseReply> getCheeseWMethod;
    if ((getCheeseWMethod = ProfitMilkGrpc.getCheeseWMethod) == null) {
      synchronized (ProfitMilkGrpc.class) {
        if ((getCheeseWMethod = ProfitMilkGrpc.getCheeseWMethod) == null) {
          ProfitMilkGrpc.getCheeseWMethod = getCheeseWMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarmOk3.third.NoCheese, grpc.DailyFarmOk3.third.NoCheeseReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DailyFarmOk3.ProfitMilk", "CheeseW"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.third.NoCheese.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.third.NoCheeseReply.getDefaultInstance()))
                  .setSchemaDescriptor(new ProfitMilkMethodDescriptorSupplier("CheeseW"))
                  .build();
          }
        }
     }
     return getCheeseWMethod;
  }

  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarmOk3.third.ProfitCheese,
      grpc.DailyFarmOk3.third.ProfitCheeseReply> getProfCheeseMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ProfCheese",
      requestType = grpc.DailyFarmOk3.third.ProfitCheese.class,
      responseType = grpc.DailyFarmOk3.third.ProfitCheeseReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.DailyFarmOk3.third.ProfitCheese,
      grpc.DailyFarmOk3.third.ProfitCheeseReply> getProfCheeseMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarmOk3.third.ProfitCheese, grpc.DailyFarmOk3.third.ProfitCheeseReply> getProfCheeseMethod;
    if ((getProfCheeseMethod = ProfitMilkGrpc.getProfCheeseMethod) == null) {
      synchronized (ProfitMilkGrpc.class) {
        if ((getProfCheeseMethod = ProfitMilkGrpc.getProfCheeseMethod) == null) {
          ProfitMilkGrpc.getProfCheeseMethod = getProfCheeseMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarmOk3.third.ProfitCheese, grpc.DailyFarmOk3.third.ProfitCheeseReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DailyFarmOk3.ProfitMilk", "ProfCheese"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.third.ProfitCheese.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.third.ProfitCheeseReply.getDefaultInstance()))
                  .setSchemaDescriptor(new ProfitMilkMethodDescriptorSupplier("ProfCheese"))
                  .build();
          }
        }
     }
     return getProfCheeseMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ProfitMilkStub newStub(io.grpc.Channel channel) {
    return new ProfitMilkStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ProfitMilkBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new ProfitMilkBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ProfitMilkFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new ProfitMilkFutureStub(channel);
  }

  /**
   */
  public static abstract class ProfitMilkImplBase implements io.grpc.BindableService {

    /**
     */
    public void totMilk(grpc.DailyFarmOk3.third.LtsMilk request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.third.LtsMilkReply> responseObserver) {
      asyncUnimplementedUnaryCall(getTotMilkMethod(), responseObserver);
    }

    /**
     */
    public void cheeseW(grpc.DailyFarmOk3.third.NoCheese request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.third.NoCheeseReply> responseObserver) {
      asyncUnimplementedUnaryCall(getCheeseWMethod(), responseObserver);
    }

    /**
     */
    public void profCheese(grpc.DailyFarmOk3.third.ProfitCheese request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.third.ProfitCheeseReply> responseObserver) {
      asyncUnimplementedUnaryCall(getProfCheeseMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getTotMilkMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.DailyFarmOk3.third.LtsMilk,
                grpc.DailyFarmOk3.third.LtsMilkReply>(
                  this, METHODID_TOT_MILK)))
          .addMethod(
            getCheeseWMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.DailyFarmOk3.third.NoCheese,
                grpc.DailyFarmOk3.third.NoCheeseReply>(
                  this, METHODID_CHEESE_W)))
          .addMethod(
            getProfCheeseMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.DailyFarmOk3.third.ProfitCheese,
                grpc.DailyFarmOk3.third.ProfitCheeseReply>(
                  this, METHODID_PROF_CHEESE)))
          .build();
    }
  }

  /**
   */
  public static final class ProfitMilkStub extends io.grpc.stub.AbstractStub<ProfitMilkStub> {
    private ProfitMilkStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ProfitMilkStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ProfitMilkStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ProfitMilkStub(channel, callOptions);
    }

    /**
     */
    public void totMilk(grpc.DailyFarmOk3.third.LtsMilk request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.third.LtsMilkReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getTotMilkMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void cheeseW(grpc.DailyFarmOk3.third.NoCheese request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.third.NoCheeseReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getCheeseWMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void profCheese(grpc.DailyFarmOk3.third.ProfitCheese request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.third.ProfitCheeseReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getProfCheeseMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class ProfitMilkBlockingStub extends io.grpc.stub.AbstractStub<ProfitMilkBlockingStub> {
    private ProfitMilkBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ProfitMilkBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ProfitMilkBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ProfitMilkBlockingStub(channel, callOptions);
    }

    /**
     */
    public grpc.DailyFarmOk3.third.LtsMilkReply totMilk(grpc.DailyFarmOk3.third.LtsMilk request) {
      return blockingUnaryCall(
          getChannel(), getTotMilkMethod(), getCallOptions(), request);
    }

    /**
     */
    public grpc.DailyFarmOk3.third.NoCheeseReply cheeseW(grpc.DailyFarmOk3.third.NoCheese request) {
      return blockingUnaryCall(
          getChannel(), getCheeseWMethod(), getCallOptions(), request);
    }

    /**
     */
    public grpc.DailyFarmOk3.third.ProfitCheeseReply profCheese(grpc.DailyFarmOk3.third.ProfitCheese request) {
      return blockingUnaryCall(
          getChannel(), getProfCheeseMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class ProfitMilkFutureStub extends io.grpc.stub.AbstractStub<ProfitMilkFutureStub> {
    private ProfitMilkFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ProfitMilkFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ProfitMilkFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ProfitMilkFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.DailyFarmOk3.third.LtsMilkReply> totMilk(
        grpc.DailyFarmOk3.third.LtsMilk request) {
      return futureUnaryCall(
          getChannel().newCall(getTotMilkMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.DailyFarmOk3.third.NoCheeseReply> cheeseW(
        grpc.DailyFarmOk3.third.NoCheese request) {
      return futureUnaryCall(
          getChannel().newCall(getCheeseWMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.DailyFarmOk3.third.ProfitCheeseReply> profCheese(
        grpc.DailyFarmOk3.third.ProfitCheese request) {
      return futureUnaryCall(
          getChannel().newCall(getProfCheeseMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_TOT_MILK = 0;
  private static final int METHODID_CHEESE_W = 1;
  private static final int METHODID_PROF_CHEESE = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final ProfitMilkImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(ProfitMilkImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_TOT_MILK:
          serviceImpl.totMilk((grpc.DailyFarmOk3.third.LtsMilk) request,
              (io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.third.LtsMilkReply>) responseObserver);
          break;
        case METHODID_CHEESE_W:
          serviceImpl.cheeseW((grpc.DailyFarmOk3.third.NoCheese) request,
              (io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.third.NoCheeseReply>) responseObserver);
          break;
        case METHODID_PROF_CHEESE:
          serviceImpl.profCheese((grpc.DailyFarmOk3.third.ProfitCheese) request,
              (io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.third.ProfitCheeseReply>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class ProfitMilkBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ProfitMilkBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return grpc.DailyFarmOk3.third.DailyFarmImplementation.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("ProfitMilk");
    }
  }

  private static final class ProfitMilkFileDescriptorSupplier
      extends ProfitMilkBaseDescriptorSupplier {
    ProfitMilkFileDescriptorSupplier() {}
  }

  private static final class ProfitMilkMethodDescriptorSupplier
      extends ProfitMilkBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    ProfitMilkMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ProfitMilkGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ProfitMilkFileDescriptorSupplier())
              .addMethod(getTotMilkMethod())
              .addMethod(getCheeseWMethod())
              .addMethod(getProfCheeseMethod())
              .build();
        }
      }
    }
    return result;
  }
}
