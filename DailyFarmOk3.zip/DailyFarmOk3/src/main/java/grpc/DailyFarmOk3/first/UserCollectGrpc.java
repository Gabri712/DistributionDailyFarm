package grpc.DailyFarmOk3.first;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 * Service Definition
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: dailyUser.proto")
public final class UserCollectGrpc {

  private UserCollectGrpc() {}

  public static final String SERVICE_NAME = "DailyFarmOk3.UserCollect";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarmOk3.first.WelcomeUserNam,
      grpc.DailyFarmOk3.first.WelcomeUserReply> getWelcomeUserMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "WelcomeUser",
      requestType = grpc.DailyFarmOk3.first.WelcomeUserNam.class,
      responseType = grpc.DailyFarmOk3.first.WelcomeUserReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.DailyFarmOk3.first.WelcomeUserNam,
      grpc.DailyFarmOk3.first.WelcomeUserReply> getWelcomeUserMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarmOk3.first.WelcomeUserNam, grpc.DailyFarmOk3.first.WelcomeUserReply> getWelcomeUserMethod;
    if ((getWelcomeUserMethod = UserCollectGrpc.getWelcomeUserMethod) == null) {
      synchronized (UserCollectGrpc.class) {
        if ((getWelcomeUserMethod = UserCollectGrpc.getWelcomeUserMethod) == null) {
          UserCollectGrpc.getWelcomeUserMethod = getWelcomeUserMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarmOk3.first.WelcomeUserNam, grpc.DailyFarmOk3.first.WelcomeUserReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DailyFarmOk3.UserCollect", "WelcomeUser"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.first.WelcomeUserNam.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.first.WelcomeUserReply.getDefaultInstance()))
                  .setSchemaDescriptor(new UserCollectMethodDescriptorSupplier("WelcomeUser"))
                  .build();
          }
        }
     }
     return getWelcomeUserMethod;
  }

  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarmOk3.first.Island,
      grpc.DailyFarmOk3.first.IslandReply> getDailyIslandMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DailyIsland",
      requestType = grpc.DailyFarmOk3.first.Island.class,
      responseType = grpc.DailyFarmOk3.first.IslandReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.DailyFarmOk3.first.Island,
      grpc.DailyFarmOk3.first.IslandReply> getDailyIslandMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarmOk3.first.Island, grpc.DailyFarmOk3.first.IslandReply> getDailyIslandMethod;
    if ((getDailyIslandMethod = UserCollectGrpc.getDailyIslandMethod) == null) {
      synchronized (UserCollectGrpc.class) {
        if ((getDailyIslandMethod = UserCollectGrpc.getDailyIslandMethod) == null) {
          UserCollectGrpc.getDailyIslandMethod = getDailyIslandMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarmOk3.first.Island, grpc.DailyFarmOk3.first.IslandReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DailyFarmOk3.UserCollect", "DailyIsland"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.first.Island.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.first.IslandReply.getDefaultInstance()))
                  .setSchemaDescriptor(new UserCollectMethodDescriptorSupplier("DailyIsland"))
                  .build();
          }
        }
     }
     return getDailyIslandMethod;
  }

  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarmOk3.first.MilkLtsCollect,
      grpc.DailyFarmOk3.first.MilkCollectReply> getMilkCollectMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "MilkCollect",
      requestType = grpc.DailyFarmOk3.first.MilkLtsCollect.class,
      responseType = grpc.DailyFarmOk3.first.MilkCollectReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.DailyFarmOk3.first.MilkLtsCollect,
      grpc.DailyFarmOk3.first.MilkCollectReply> getMilkCollectMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarmOk3.first.MilkLtsCollect, grpc.DailyFarmOk3.first.MilkCollectReply> getMilkCollectMethod;
    if ((getMilkCollectMethod = UserCollectGrpc.getMilkCollectMethod) == null) {
      synchronized (UserCollectGrpc.class) {
        if ((getMilkCollectMethod = UserCollectGrpc.getMilkCollectMethod) == null) {
          UserCollectGrpc.getMilkCollectMethod = getMilkCollectMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarmOk3.first.MilkLtsCollect, grpc.DailyFarmOk3.first.MilkCollectReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DailyFarmOk3.UserCollect", "MilkCollect"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.first.MilkLtsCollect.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.first.MilkCollectReply.getDefaultInstance()))
                  .setSchemaDescriptor(new UserCollectMethodDescriptorSupplier("MilkCollect"))
                  .build();
          }
        }
     }
     return getMilkCollectMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static UserCollectStub newStub(io.grpc.Channel channel) {
    return new UserCollectStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static UserCollectBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new UserCollectBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static UserCollectFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new UserCollectFutureStub(channel);
  }

  /**
   * <pre>
   * Service Definition
   * </pre>
   */
  public static abstract class UserCollectImplBase implements io.grpc.BindableService {

    /**
     */
    public void welcomeUser(grpc.DailyFarmOk3.first.WelcomeUserNam request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.first.WelcomeUserReply> responseObserver) {
      asyncUnimplementedUnaryCall(getWelcomeUserMethod(), responseObserver);
    }

    /**
     */
    public void dailyIsland(grpc.DailyFarmOk3.first.Island request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.first.IslandReply> responseObserver) {
      asyncUnimplementedUnaryCall(getDailyIslandMethod(), responseObserver);
    }

    /**
     */
    public void milkCollect(grpc.DailyFarmOk3.first.MilkLtsCollect request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.first.MilkCollectReply> responseObserver) {
      asyncUnimplementedUnaryCall(getMilkCollectMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getWelcomeUserMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.DailyFarmOk3.first.WelcomeUserNam,
                grpc.DailyFarmOk3.first.WelcomeUserReply>(
                  this, METHODID_WELCOME_USER)))
          .addMethod(
            getDailyIslandMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.DailyFarmOk3.first.Island,
                grpc.DailyFarmOk3.first.IslandReply>(
                  this, METHODID_DAILY_ISLAND)))
          .addMethod(
            getMilkCollectMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.DailyFarmOk3.first.MilkLtsCollect,
                grpc.DailyFarmOk3.first.MilkCollectReply>(
                  this, METHODID_MILK_COLLECT)))
          .build();
    }
  }

  /**
   * <pre>
   * Service Definition
   * </pre>
   */
  public static final class UserCollectStub extends io.grpc.stub.AbstractStub<UserCollectStub> {
    private UserCollectStub(io.grpc.Channel channel) {
      super(channel);
    }

    private UserCollectStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected UserCollectStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new UserCollectStub(channel, callOptions);
    }

    /**
     */
    public void welcomeUser(grpc.DailyFarmOk3.first.WelcomeUserNam request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.first.WelcomeUserReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getWelcomeUserMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void dailyIsland(grpc.DailyFarmOk3.first.Island request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.first.IslandReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getDailyIslandMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void milkCollect(grpc.DailyFarmOk3.first.MilkLtsCollect request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.first.MilkCollectReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getMilkCollectMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * Service Definition
   * </pre>
   */
  public static final class UserCollectBlockingStub extends io.grpc.stub.AbstractStub<UserCollectBlockingStub> {
    private UserCollectBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private UserCollectBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected UserCollectBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new UserCollectBlockingStub(channel, callOptions);
    }

    /**
     */
    public grpc.DailyFarmOk3.first.WelcomeUserReply welcomeUser(grpc.DailyFarmOk3.first.WelcomeUserNam request) {
      return blockingUnaryCall(
          getChannel(), getWelcomeUserMethod(), getCallOptions(), request);
    }

    /**
     */
    public grpc.DailyFarmOk3.first.IslandReply dailyIsland(grpc.DailyFarmOk3.first.Island request) {
      return blockingUnaryCall(
          getChannel(), getDailyIslandMethod(), getCallOptions(), request);
    }

    /**
     */
    public grpc.DailyFarmOk3.first.MilkCollectReply milkCollect(grpc.DailyFarmOk3.first.MilkLtsCollect request) {
      return blockingUnaryCall(
          getChannel(), getMilkCollectMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * Service Definition
   * </pre>
   */
  public static final class UserCollectFutureStub extends io.grpc.stub.AbstractStub<UserCollectFutureStub> {
    private UserCollectFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private UserCollectFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected UserCollectFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new UserCollectFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.DailyFarmOk3.first.WelcomeUserReply> welcomeUser(
        grpc.DailyFarmOk3.first.WelcomeUserNam request) {
      return futureUnaryCall(
          getChannel().newCall(getWelcomeUserMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.DailyFarmOk3.first.IslandReply> dailyIsland(
        grpc.DailyFarmOk3.first.Island request) {
      return futureUnaryCall(
          getChannel().newCall(getDailyIslandMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.DailyFarmOk3.first.MilkCollectReply> milkCollect(
        grpc.DailyFarmOk3.first.MilkLtsCollect request) {
      return futureUnaryCall(
          getChannel().newCall(getMilkCollectMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_WELCOME_USER = 0;
  private static final int METHODID_DAILY_ISLAND = 1;
  private static final int METHODID_MILK_COLLECT = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final UserCollectImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(UserCollectImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_WELCOME_USER:
          serviceImpl.welcomeUser((grpc.DailyFarmOk3.first.WelcomeUserNam) request,
              (io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.first.WelcomeUserReply>) responseObserver);
          break;
        case METHODID_DAILY_ISLAND:
          serviceImpl.dailyIsland((grpc.DailyFarmOk3.first.Island) request,
              (io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.first.IslandReply>) responseObserver);
          break;
        case METHODID_MILK_COLLECT:
          serviceImpl.milkCollect((grpc.DailyFarmOk3.first.MilkLtsCollect) request,
              (io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.first.MilkCollectReply>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class UserCollectBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    UserCollectBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return grpc.DailyFarmOk3.first.DailyFarmImplementation.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("UserCollect");
    }
  }

  private static final class UserCollectFileDescriptorSupplier
      extends UserCollectBaseDescriptorSupplier {
    UserCollectFileDescriptorSupplier() {}
  }

  private static final class UserCollectMethodDescriptorSupplier
      extends UserCollectBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    UserCollectMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (UserCollectGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new UserCollectFileDescriptorSupplier())
              .addMethod(getWelcomeUserMethod())
              .addMethod(getDailyIslandMethod())
              .addMethod(getMilkCollectMethod())
              .build();
        }
      }
    }
    return result;
  }
}
