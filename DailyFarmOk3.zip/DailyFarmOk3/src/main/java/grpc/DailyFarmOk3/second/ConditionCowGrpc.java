package grpc.DailyFarmOk3.second;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 * Service Definition
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: advice.proto")
public final class ConditionCowGrpc {

  private ConditionCowGrpc() {}

  public static final String SERVICE_NAME = "DailyFarmOk3.ConditionCow";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarmOk3.second.KgsCow,
      grpc.DailyFarmOk3.second.KgsCowReply> getWeigCowMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "WeigCow",
      requestType = grpc.DailyFarmOk3.second.KgsCow.class,
      responseType = grpc.DailyFarmOk3.second.KgsCowReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.DailyFarmOk3.second.KgsCow,
      grpc.DailyFarmOk3.second.KgsCowReply> getWeigCowMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarmOk3.second.KgsCow, grpc.DailyFarmOk3.second.KgsCowReply> getWeigCowMethod;
    if ((getWeigCowMethod = ConditionCowGrpc.getWeigCowMethod) == null) {
      synchronized (ConditionCowGrpc.class) {
        if ((getWeigCowMethod = ConditionCowGrpc.getWeigCowMethod) == null) {
          ConditionCowGrpc.getWeigCowMethod = getWeigCowMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarmOk3.second.KgsCow, grpc.DailyFarmOk3.second.KgsCowReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DailyFarmOk3.ConditionCow", "WeigCow"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.second.KgsCow.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.second.KgsCowReply.getDefaultInstance()))
                  .setSchemaDescriptor(new ConditionCowMethodDescriptorSupplier("WeigCow"))
                  .build();
          }
        }
     }
     return getWeigCowMethod;
  }

  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarmOk3.second.LtsCow,
      grpc.DailyFarmOk3.second.LtsCowReply> getMilkCowMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "MilkCow",
      requestType = grpc.DailyFarmOk3.second.LtsCow.class,
      responseType = grpc.DailyFarmOk3.second.LtsCowReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.DailyFarmOk3.second.LtsCow,
      grpc.DailyFarmOk3.second.LtsCowReply> getMilkCowMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarmOk3.second.LtsCow, grpc.DailyFarmOk3.second.LtsCowReply> getMilkCowMethod;
    if ((getMilkCowMethod = ConditionCowGrpc.getMilkCowMethod) == null) {
      synchronized (ConditionCowGrpc.class) {
        if ((getMilkCowMethod = ConditionCowGrpc.getMilkCowMethod) == null) {
          ConditionCowGrpc.getMilkCowMethod = getMilkCowMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarmOk3.second.LtsCow, grpc.DailyFarmOk3.second.LtsCowReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DailyFarmOk3.ConditionCow", "MilkCow"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.second.LtsCow.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.second.LtsCowReply.getDefaultInstance()))
                  .setSchemaDescriptor(new ConditionCowMethodDescriptorSupplier("MilkCow"))
                  .build();
          }
        }
     }
     return getMilkCowMethod;
  }

  private static volatile io.grpc.MethodDescriptor<grpc.DailyFarmOk3.second.ConditCow,
      grpc.DailyFarmOk3.second.ConditCowReply> getAdvCowMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AdvCow",
      requestType = grpc.DailyFarmOk3.second.ConditCow.class,
      responseType = grpc.DailyFarmOk3.second.ConditCowReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.DailyFarmOk3.second.ConditCow,
      grpc.DailyFarmOk3.second.ConditCowReply> getAdvCowMethod() {
    io.grpc.MethodDescriptor<grpc.DailyFarmOk3.second.ConditCow, grpc.DailyFarmOk3.second.ConditCowReply> getAdvCowMethod;
    if ((getAdvCowMethod = ConditionCowGrpc.getAdvCowMethod) == null) {
      synchronized (ConditionCowGrpc.class) {
        if ((getAdvCowMethod = ConditionCowGrpc.getAdvCowMethod) == null) {
          ConditionCowGrpc.getAdvCowMethod = getAdvCowMethod = 
              io.grpc.MethodDescriptor.<grpc.DailyFarmOk3.second.ConditCow, grpc.DailyFarmOk3.second.ConditCowReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DailyFarmOk3.ConditionCow", "AdvCow"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.second.ConditCow.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.DailyFarmOk3.second.ConditCowReply.getDefaultInstance()))
                  .setSchemaDescriptor(new ConditionCowMethodDescriptorSupplier("AdvCow"))
                  .build();
          }
        }
     }
     return getAdvCowMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ConditionCowStub newStub(io.grpc.Channel channel) {
    return new ConditionCowStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ConditionCowBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new ConditionCowBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ConditionCowFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new ConditionCowFutureStub(channel);
  }

  /**
   * <pre>
   * Service Definition
   * </pre>
   */
  public static abstract class ConditionCowImplBase implements io.grpc.BindableService {

    /**
     */
    public void weigCow(grpc.DailyFarmOk3.second.KgsCow request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.second.KgsCowReply> responseObserver) {
      asyncUnimplementedUnaryCall(getWeigCowMethod(), responseObserver);
    }

    /**
     */
    public void milkCow(grpc.DailyFarmOk3.second.LtsCow request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.second.LtsCowReply> responseObserver) {
      asyncUnimplementedUnaryCall(getMilkCowMethod(), responseObserver);
    }

    /**
     */
    public void advCow(grpc.DailyFarmOk3.second.ConditCow request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.second.ConditCowReply> responseObserver) {
      asyncUnimplementedUnaryCall(getAdvCowMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getWeigCowMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.DailyFarmOk3.second.KgsCow,
                grpc.DailyFarmOk3.second.KgsCowReply>(
                  this, METHODID_WEIG_COW)))
          .addMethod(
            getMilkCowMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.DailyFarmOk3.second.LtsCow,
                grpc.DailyFarmOk3.second.LtsCowReply>(
                  this, METHODID_MILK_COW)))
          .addMethod(
            getAdvCowMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.DailyFarmOk3.second.ConditCow,
                grpc.DailyFarmOk3.second.ConditCowReply>(
                  this, METHODID_ADV_COW)))
          .build();
    }
  }

  /**
   * <pre>
   * Service Definition
   * </pre>
   */
  public static final class ConditionCowStub extends io.grpc.stub.AbstractStub<ConditionCowStub> {
    private ConditionCowStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ConditionCowStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ConditionCowStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ConditionCowStub(channel, callOptions);
    }

    /**
     */
    public void weigCow(grpc.DailyFarmOk3.second.KgsCow request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.second.KgsCowReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getWeigCowMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void milkCow(grpc.DailyFarmOk3.second.LtsCow request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.second.LtsCowReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getMilkCowMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void advCow(grpc.DailyFarmOk3.second.ConditCow request,
        io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.second.ConditCowReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getAdvCowMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * Service Definition
   * </pre>
   */
  public static final class ConditionCowBlockingStub extends io.grpc.stub.AbstractStub<ConditionCowBlockingStub> {
    private ConditionCowBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ConditionCowBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ConditionCowBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ConditionCowBlockingStub(channel, callOptions);
    }

    /**
     */
    public grpc.DailyFarmOk3.second.KgsCowReply weigCow(grpc.DailyFarmOk3.second.KgsCow request) {
      return blockingUnaryCall(
          getChannel(), getWeigCowMethod(), getCallOptions(), request);
    }

    /**
     */
    public grpc.DailyFarmOk3.second.LtsCowReply milkCow(grpc.DailyFarmOk3.second.LtsCow request) {
      return blockingUnaryCall(
          getChannel(), getMilkCowMethod(), getCallOptions(), request);
    }

    /**
     */
    public grpc.DailyFarmOk3.second.ConditCowReply advCow(grpc.DailyFarmOk3.second.ConditCow request) {
      return blockingUnaryCall(
          getChannel(), getAdvCowMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * Service Definition
   * </pre>
   */
  public static final class ConditionCowFutureStub extends io.grpc.stub.AbstractStub<ConditionCowFutureStub> {
    private ConditionCowFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ConditionCowFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ConditionCowFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ConditionCowFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.DailyFarmOk3.second.KgsCowReply> weigCow(
        grpc.DailyFarmOk3.second.KgsCow request) {
      return futureUnaryCall(
          getChannel().newCall(getWeigCowMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.DailyFarmOk3.second.LtsCowReply> milkCow(
        grpc.DailyFarmOk3.second.LtsCow request) {
      return futureUnaryCall(
          getChannel().newCall(getMilkCowMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.DailyFarmOk3.second.ConditCowReply> advCow(
        grpc.DailyFarmOk3.second.ConditCow request) {
      return futureUnaryCall(
          getChannel().newCall(getAdvCowMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_WEIG_COW = 0;
  private static final int METHODID_MILK_COW = 1;
  private static final int METHODID_ADV_COW = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final ConditionCowImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(ConditionCowImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_WEIG_COW:
          serviceImpl.weigCow((grpc.DailyFarmOk3.second.KgsCow) request,
              (io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.second.KgsCowReply>) responseObserver);
          break;
        case METHODID_MILK_COW:
          serviceImpl.milkCow((grpc.DailyFarmOk3.second.LtsCow) request,
              (io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.second.LtsCowReply>) responseObserver);
          break;
        case METHODID_ADV_COW:
          serviceImpl.advCow((grpc.DailyFarmOk3.second.ConditCow) request,
              (io.grpc.stub.StreamObserver<grpc.DailyFarmOk3.second.ConditCowReply>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class ConditionCowBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ConditionCowBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return grpc.DailyFarmOk3.second.DailyFarmImplementation.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("ConditionCow");
    }
  }

  private static final class ConditionCowFileDescriptorSupplier
      extends ConditionCowBaseDescriptorSupplier {
    ConditionCowFileDescriptorSupplier() {}
  }

  private static final class ConditionCowMethodDescriptorSupplier
      extends ConditionCowBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    ConditionCowMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ConditionCowGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ConditionCowFileDescriptorSupplier())
              .addMethod(getWeigCowMethod())
              .addMethod(getMilkCowMethod())
              .addMethod(getAdvCowMethod())
              .build();
        }
      }
    }
    return result;
  }
}
